import numpy as np
import cv2
import random


def gen_img(data, out_path, fre_per_point, start, end, offset, height, width, val, line_width):
    global img
    data = data[start + offset:end + offset]
    length = len(data)

    zero_data = np.zeros((length, 150, 3), np.uint8)  # (1100, 150, 3)
    ptStart = (int(data[0] + 50), 0)

    point_white = (255, 255, 255)  # BGR
    point_green = (0, 255, 0)
    thickness = line_width
    lineType = cv2.LINE_4

    for i in range(1, len(data)):
        zero_data[i, int(data[i]) + 50] = 255
        ptEnd = (int(data[i] + 50), i)
        if int(data[i] + 50) > 50:
            img = cv2.line(zero_data, ptStart, ptEnd, point_green, thickness, lineType)
        else:
            img = cv2.line(zero_data, ptStart, ptEnd, point_white, thickness, lineType)

        ptStart = (int(data[i] + 50), i)

    img = cv2.resize(img, (width, height))
    img = np.rot90(img)

    start_fre = (30000 + (start + offset) * fre_per_point) / 1000
    end_fre = (30000 + (end + offset) * fre_per_point) / 1000

    frequency_band = str(round(start_fre, 2)) + '~' + str(round(end_fre, 2)) + 'MHZ'
    val = 'image' + '_' + val
    file_name = val + '_' + frequency_band + '_' + str(start + offset)
    cv2.imwrite(out_path + '/' + str(file_name) + ".jpg", img)


#  3.125KHZ处理方式
#  QPSK出现的频点：670000~690000                      设置带宽点数bw_points=4000    start_fre_points=670000
#  GSM出现的频点:282000~320000 560000~600000          设置带宽点数bw_points=800     start_fre_points=282000 or 560000
#  FM 主要集中在 0~20000， AM各个频段都有              设置带宽点数bw_points800      start_fre_points=0
#  图片分辨率统一为 850x550

def plotSpectrum_3125(filename, out_path, start_fre_points, bw_points, line_width):
    '''
    参数说明：
    filename ： 频谱数据集.dat文件路径
    out_path ： 信号图片输出路径
    start_fre_points：各类信号在全频段上出现的起始位置，具体设置上面有参考数值
    bw_points：带宽点数 ，AM、FM、GSM设置为 800， QPSK设置为 4000
    line_width:线宽，AM、FM、GSM设置为 1， QPSK设置为 2
    '''

    lengthx = 950400
    step = 3.125  # 扫描步进

    name = 'fre_3.125'
    data = np.fromfile(filename, dtype=np.int16)
    data = data / 10
    num = len(data) // lengthx

    # 随机帧
    rand_num = random.randint(0, num - 1)
    spectrum_data = data[rand_num * lengthx: (rand_num + 1) * lengthx]

    offset = [20, 30, 40, 50, 60, 70, 80, 90, 100]
    mul = [11, 22, 33, 44, 55, 66, 77, 88, 90]

    start = start_fre_points  # 指定起始频率点数start_fre_points

    # 随机产生训练图片
    for y in range(20):
        start = start_fre_points + y * 40
        for x in range(20):

            mul_ = random.choice(mul)
            offset_ = random.choice(offset)
            points = bw_points
            end = start + points

            if end > lengthx:
                print("The End: ", end)
                break
            else:
                gen_img(spectrum_data, out_path, step, start, end, mul_ * offset_, 850, 550, name, line_width)
                start = end


#  6.25KHZ处理方式
#  QPSK出现的频点：335946~350000                      设置带宽点数bw_points=3600    start_fre_points=335946
#  GSM出现的频点:144562~220000 287089~310000          设置带宽点数bw_points=900     start_fre_points=144562 or 287089
#  FM 主要集中在 0~20000， AM各个频段都有               设置带宽点数bw_points=900      start_fre_points=0
#  图片分辨率统一为850x550

def plotSpectrum_625(filename, out_path, start_fre_points, bw_points, line_width):
    '''
    参数说明：
    filename ： 频谱数据.dat文件路径
    out_path ： 图片输出路径
    start_fre_points：各类信号在全频段上出现的起始位置，具体设置上面有参考数值
    bw_points：带宽点数 ，AM、FM、GSM设置为900  ，QPSK设置为3600
    line_width:线宽，AM、FM、GSM设置为1， QPSK设置为2
    '''

    lengthx = 475200
    step = 6.25  # 扫描步进

    data = np.fromfile(filename, dtype=np.int16)
    data = data / 10
    num = len(data) // lengthx
    mul = [55, 66, 77, 88]

    # 随机帧
    rand_num = random.randint(0, num - 1)
    spectrum_data = data[rand_num * lengthx: (rand_num + 1) * lengthx]

    offset = [10, 20, 30, 40, 50, 60]
    name = 'fre_6.25'
    points = bw_points

    start_flag = start_fre_points  # 指定其实频率
    for y in range(20):
        start = start_fre_points + y * 5
        for x in range(20):
            mul_ = random.choice(mul)
            offset_ = random.choice(offset)
            end = start + points
            if end > lengthx:
                print("end:", end)
                break
            else:
                gen_img(spectrum_data, out_path, step, start, end, mul_ * offset_, 850, 550, name, line_width)
                start = end


if __name__ == "__main__":

    input_path = "./Spectrum_Dataset/" \
                 "30MHz-3000MHz-3.125KHz.dat"
    output_path = "./Intermediate"
    plotSpectrum_625(input_path, output_path, 320000, 3600, 2)

    print("Data Processing Has Been Completed !")
