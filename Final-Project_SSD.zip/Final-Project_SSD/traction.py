import os

filePath = 'C://Users//DEFAULT.DESKTOP-KHG6I9R//Desktop//Testing'
list_data=os.listdir(filePath)
file = open('train_val‪.txt', 'w+')
for i in list_data:
    i = i[:-4]
    file.write(i + '\n')
file.close()
