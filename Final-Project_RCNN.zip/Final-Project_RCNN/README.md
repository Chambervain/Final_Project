# Faster R-CNN

## 环境配置：
* Python 3.7 (Anaconda)
* Pytorch 1.6
* pycocotools(Linux:```pip install pycocotools```; Windows:```pip install pycocotools-windows```
* Operating System: Linux/Windows

## 文件结构：
```
  ├── backbone: 特征提取网络，可以根据要求进行选择
  ├── network_files: Faster R-CNN网络（包括Fast R-CNN以及RPN等模块）
  ├── train_utils: 训练验证相关模块（包括cocotools）
  ├── my_dataset.py: 自定义dataset用于读取VOC数据集
  ├── train_mobilenet.py: 以MobileNetV2做为backbone进行训练
  ├── train_resnet50_fpn.py: 以resnet50+FPN做为backbone进行训练
  ├── train_multi_GPU.py: 针对使用多GPU进行训练
  ├── predict.py: 预测脚本文件，使用训练好的权重进行预测测试
  ├── validation.py: 利用训练好的权重验证/测试数据的COCO指标，并生成record_mAP.txt文件
  └── pascal_voc_classes.json: pascal_voc标签文件
```

## 预训练权重下载地址（下载后放入backbone文件夹中）：
* MobileNetV2 backbone: https://download.pytorch.org/models/mobilenet_v2-b0353104.pth
* ResNet50+FPN backbone: https://download.pytorch.org/models/fasterrcnn_resnet50_fpn_coco-258fb6c6.pth
 
## 数据集使用的是PASCAL VOC格式数据集，由LabelImg软件进行标注 

## 训练方法
* 提前准备好数据集
* 提前下载好对应预训练模型权重
* 若要训练mobilenetv2+fasterrcnn，直接使用train_mobilenet.py训练脚本
* 若要训练resnet50+fpn+fasterrcnn，直接使用train_resnet50_fpn.py训练脚本
* 若要使用多GPU训练，使用```python -m torch.distributed.launch --nproc_per_node=8 --use_env train_multi_GPU.py```指令,```nproc_per_node```参数为使用GPU数量

## 注意事项
* 在使用训练脚本时，要将'--data-path'(VOC_root)设置为自己存放'VOCdevkit'文件夹所在的**根目录**
* 由于带有FPN结构的Faster RCNN非常占显存，如果GPU的显存不够(若batch_size小于8的话)，在create_model函数中使用默认的norm_layer，
  即不传递norm_layer变量，默认去使用FrozenBatchNorm2d(则不会去更新参数的bn层)
* 在使用预测脚本时，要将'train_weights'设置为自己生成的权重路径。
* 使用validation文件时，注意确保验证集或者测试集中必须包含每个类别的目标，并且使用时只需要修改'--num-classes'、'--data-path'和'--weights'即可
